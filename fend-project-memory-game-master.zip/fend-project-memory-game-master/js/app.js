/*
 * Create a list that holds all of your cards, 2 cards for 1 pair reach
 */
//const cards = [
var cards = [
    'fa-diamond', 'fa-diamond',
    'fa-paper-plane-o', 'fa-paper-plane-o',
    'fa-anchor', 'fa-anchor',
    'fa-bolt', 'fa-bolt',
    'fa-cube', 'fa-cube',
    'fa-leaf', 'fa-leaf',
    'fa-bicycle', 'fa-bicycle',
    'fa-bomb', 'fa-bomb',
];
//html-card template for each card
function generateCard(card){
    //var  i;
	/*
    while (cards[i] && i < 16){
        return '<li class="card match"><i class="fa ${card}"></i></li>';
		i++;
    }
*/
/*
	for (i=0; 0<16; i++){
		return '<li class="card match"><i class="fa card[i]"></i></li>';
	}
	*/
    return '<li class="card match"><i class="fa ${card}"></i></li>';
    //return '<li class="card match"><i class="fa fa-cube"></i></li>';
	//return '<li class="card match"><i class="fa this.card"></i></li>';
}

/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */
// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array){
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */
function initGame(){
    //write deck-ul in deck-array
    //const deck = document.querySelector('.deck');
    var deck = document.querySelector('.deck');

    //karten werden ohne klassen in cardHTML-array hinzugefuegt
    //let cardHTML = shuffle(cards).map(function(card){
	var cardHTML = cards.map(function(card){
        return generateCard(card);
    });

    //moves = 0;
    //moveCounter.innerText = moves; //steigt hier aus

    //create game cards programatically
    deck.innerHTML = cardHTML.join('');
}

/*
function removeStar(){
	//document.getElementById('stars').class.remove;
	this.class('fa-star').remove();
}
*/

initGame();

var allCards = document.querySelectorAll('.card');
//empty card-compare-array
var openCards = [];
//var moves = 0;
//var moveCounter = document.querySelector('moves');

allCards.forEach(function(card){
    //click eventlistener
    card.addEventListener('click', function(e){

        //if the clicked card is still closed
        if (!card.classList.contains('open') && !card.classList.contains('show') && !card.classList.contains('match')){

            openCards.push(card);
            card.classList.add('open', 'show');

            if (openCards.length == 2){
                //card match found in first and second click
                if (openCards[0].dataset.card == openCards[1].dataset.card){
                    //register first card pick
                    openCards[0].classList.add('match');
                    openCards[0].classList.add('open');
                    openCards[0].classList.add('show');

                    //register second card pick//register first card pick
                    openCards[1].classList.add('match');
                    openCards[1].classList.add('open');
                    openCards[1].classList.add('show');

                    //clear card-compare-array again
                    openCards = [];
                } else {
                    //no match
                    setTimeout(function(){
                        openCards.forEach(function(card){
                            //hide again
                            card.classList.remove('open', 'show');
                        });
						//remove star
						//removeStar();
                        //clear card-compare-array again
                        openCards = [];
                    }, 1000); //1000ms break for having enough click time
                }

            //    moves += 1;
            //    moveCounter.innerText = moves;
            }

        }

    });
});

/*
//randomizer works, always the same 3 card types though (no class-change)
createDeck()
 function createDeck() {
  const cardList = document.querySelectorAll('.card'); //selects all cards from html
  const cardArray = Array.from(cardList); //puts the cards into an array
  const shuffleArray = shuffle(cardArray); //shuffles the array of cards
  for (i=0; i < cardList.length; i++) {
   const oldCard = cardList[i];
   oldCard.remove();
} //loops over the array of cards and removes old cards from the html so they aren't doubled on screen
  const deckFragment = document.createDocumentFragment();
  for (i=0; i < shuffleArray.length; i++) {
   const newCard = document.createElement('li');
   newCard.innerHTML = shuffleArray[i].innerHTML;
   newCard.className = shuffleArray[i].className;
    newCard.addEventListener('click', flipCard); //add the addEventListener to each card
   deckFragment.appendChild(newCard);
} //creates the new shuffled deck of cards using document fragment
  const newDeckList = document.querySelector('.deck');
  newDeckList.appendChild(deckFragment); //displays the newly shuffled deck
}
//function doesn't work
function flipCard(e){
  e.target.classList.toggle("card open show");
}
*/
